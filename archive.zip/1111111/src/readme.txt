i learn this laji

wo you jia le yi hang le 