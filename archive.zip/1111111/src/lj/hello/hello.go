package main

import (
	"fmt"
	"lj/stringutil"
)

func main() {
	fmt.Printf(stringutil.Reverse("Hello, world.\n"))
}
